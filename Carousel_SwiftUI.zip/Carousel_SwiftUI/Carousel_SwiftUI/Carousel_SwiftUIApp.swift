//
//  Carousel_SwiftUIApp.swift
//  Carousel_SwiftUI
//
//  Created by Anthony Codes on 15/09/2020.
//

import SwiftUI

@main
struct Carousel_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
