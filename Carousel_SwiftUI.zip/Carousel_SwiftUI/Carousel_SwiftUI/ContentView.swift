//
//  ContentView.swift
//  Carousel_SwiftUI
//
//  Created by Anthony Codes on 15/09/2020.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Home : View {
    //View
    var width = UIScreen.main.bounds.width - (40 + 60)
    var height = UIScreen.main.bounds.height / 2
    @State var swiped = 0
    //BookData
    @State var books = [
        
        Book(id: 0, image: "p1", title: "October Greates", author: "Agatha", rating: 3, offset: 0),
        Book(id: 1, image: "p0", title: "October Greates", author: "Arthur", rating: 4, offset: 0),
        Book(id: 2, image: "p3", title: "October Greates", author: "Larsson", rating: 4, offset: 0),
        Book(id: 3, image: "p2", title: "October Greates", author: "Mario", rating: 5, offset: 0),
        Book(id: 4, image: "p5", title: "October Greates", author: "Alice", rating: 4, offset: 0),
        Book(id: 5, image: "p4", title: "October Greates", author: "Daphne", rating: 4, offset: 0),
    ]

    var body: some View{
        VStack {
            HStack {
                Text("Recipe Books")
                    .font(.system(size: 42, weight: .bold))
                    .padding(.leading, 30)
                Spacer()
                Button(action: {}) {
                    Image(systemName: "square.grid.2x2.fill")
                        .font(.system(size: 30))
                        .padding(.trailing, 30)
                }
            }
            .foregroundColor(.white)
            .padding(.top, 50)
            Spacer()
            
            ZStack {
                ForEach(books.reversed()){book in
                    HStack {
                        ZStack {
                            Image(book.image)
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: width, height: getHeight(index: book.id))
                                .cornerRadius(15)
                                .shadow(color: Color.black.opacity(0.1), radius: 5, x: 5)
                            
                            CardView(card: book)
                                .frame(width: width, height: getHeight(index: book.id))
                        }
                        Spacer(minLength: 0)
                    }
                    .contentShape(Rectangle())
                    .padding(.horizontal,20)
                    .offset(x: book.id - swiped < 3 ? CGFloat(book.id - swiped) * 30 : 60)
                    .offset(x: book.offset)
                    .gesture(DragGesture().onChanged({ (value) in
                        withAnimation{onScroll(value: value.translation.width, index: book.id)}
                    }).onEnded({ (value) in
                        withAnimation{onEnd(value: value.translation.width, index: book.id)}
                    }))
                }
            }
            .frame(height: height)
            PageViewController(total: books.count, current: $swiped)
                .padding(.top,25)
            Spacer(minLength: 0)
        }
        .background(Color("bg").ignoresSafeArea(.all, edges: .all))
    }
    
func getHeight(index : Int)->CGFloat {
    return height - (index - swiped < 3 ? CGFloat(index - swiped) * 40 : 80)
}
    
func onScroll(value: CGFloat,index: Int) {
    if value < 0 {
        //SwipeLeft
        if index != books.last!.id {
            books[index].offset = value
        }
    } else {
        //SwipeRight
        if index > 0 {
            books[index - 1].offset = -(width + 60) + value
        }
    }
}

func onEnd(value: CGFloat,index: Int) {
    if value < 0 {
        if -value > width / 2 && index != books.last!.id {
            books[index].offset = -(width + 60)
            swiped += 1
        } else {
            books[index].offset = 0
        }
    } else {
        if index > 0 {
            if value > width / 2 {
                books[index - 1].offset = 0
                swiped -= 1
            } else {
                books[index - 1].offset = -(width + 60)
                }
            }
        }
    }
}

struct CardView : View {
    
    var card : Book
    
    var body: some View {
        VStack {
            Spacer(minLength: 0)
            HStack {
                Button(action: {}) {
                    Text("Read Now")
                        .font(.system(size: 14))
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.vertical,5)
                        .padding(.horizontal,10)
                        .background(Color("purple"))
                        .clipShape(Capsule())
                }
                Spacer(minLength: 0)
            }
            .padding()
            .padding(.bottom,10)
        }
    }
}

// BookData

struct Book : Identifiable {
    
    var id: Int
    var image : String
    var title : String
    var author : String
    var rating : Int
    var offset : CGFloat
}

//PagingControl

struct PageViewController : UIViewRepresentable {
    
    var total : Int
    @Binding var current : Int
    
    func makeUIView(context: Context) -> UIPageControl {
        
        let view = UIPageControl()
        view.numberOfPages = total
        view.currentPage = current
        view.currentPageIndicatorTintColor = .white
        view.preferredIndicatorImage = UIImage(systemName: "book.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 32))
        view.backgroundStyle = .prominent
        
        return view
    }
    
    func updateUIView(_ uiView: UIPageControl, context: Context) {
        
        uiView.currentPage = current
    }
}
